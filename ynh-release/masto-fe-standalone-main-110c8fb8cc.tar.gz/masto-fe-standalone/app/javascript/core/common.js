//  This file will be loaded on all pages, regardless of theme.

import 'packs/public-path';
import 'font-awesome/css/font-awesome.css';

require.context('../images/', true);
