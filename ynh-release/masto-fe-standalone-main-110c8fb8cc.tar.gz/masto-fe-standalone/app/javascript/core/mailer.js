import '../styles/mailer.scss';

require.context('../icons');
