module.exports = {
  singleQuote: true,
  jsxSingleQuote: true
}
